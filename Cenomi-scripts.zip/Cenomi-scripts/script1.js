// Load the AWS SDK for Node.js

const operations = require("./operations");
const roles = require("./roles");

const AWS = require("aws-sdk");
// Set the region
AWS.config.update({
  region: process.argv[2],
  credentials: {
    accessKeyId: process.argv[3],
    secretAccessKey: process.argv[4],
  },
});

// Name of the Table for UserManagement
const userManagementTable = "Cenomi-Integration-SIT-Config";

// Create DynamoDB document client
var docClient = new AWS.DynamoDB.DocumentClient();

const populateOperations = async () => {
  const failedUpdateList = [];
  for (let pkSkIndex = 0; pkSkIndex < operations.length; pkSkIndex++) {
    let pkSkDataObj = operations[pkSkIndex];
    try {
      const putItemParams = {
        TableName: userManagementTable,
        Item: {
          ...pkSkDataObj
        },
      };
      await docClient.put(putItemParams).promise();
    } catch (err) {
      console.log("Error:", err);
      failedUpdateList.push(pkSkDataObj);
    }
    console.log(`Successfully Updated Operations PK:${pkSkDataObj.PK} SK:${pkSkDataObj.SK}`);
  }
  if(failedUpdateList.length == 0){
    console.log("ALL ITEMS Processed");
  }else{
    console.log("FAILED ITEMS", JSON.stringify(failedUpdateList));
  }
};

const populateRoles = async () => {
  const failedUpdateList = [];
  for (let pkSkIndex = 0; pkSkIndex < roles.length; pkSkIndex++) {
    let pkSkDataObj = roles[pkSkIndex];
    try {
      const putItemParams = {
        TableName: userManagementTable,
        Item: {
          ...pkSkDataObj
        },
      };
      await docClient.put(putItemParams).promise();
    } catch (err) {
      console.log("Error:", err);
      failedUpdateList.push(pkSkDataObj);
    }
    console.log(`Successfully Updated Roles PK:${pkSkDataObj.PK} SK:${pkSkDataObj.SK}`);
  }
  if(failedUpdateList.length == 0){
    console.log("All Items processed");
  }else{
    console.log("FAILED ITEMS", JSON.stringify(failedUpdateList));
  }
};

populateOperations().then((data) => {
  console.log("Script populateOperations Processing Completed");
});

populateRoles().then((data) => {
  console.log("Script populateRoles Processing Completed");
});
