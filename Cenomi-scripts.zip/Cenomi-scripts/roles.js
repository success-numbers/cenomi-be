module.exports = [
    {
        "PK": "ADMIN",
        "SK": "ADMIN",
        "access": "FFFFFFFFFFFFFFF",
        "active": true,
        "createDate": 1706130672000,
        "createdBy": "SuperUser",
        "entityType": "ROLE",
        "updateDate": 1706130672000,
        "updatedBy": "SuperUser"
    }
]

