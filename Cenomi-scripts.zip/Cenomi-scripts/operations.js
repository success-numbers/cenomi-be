module.exports = [
    {
    "PK": "0",
    "SK": "0",
    "active": true,
    "createDate": 1704869809,
    "entityType": "OPERATION",
    "operationDesc": "USER MANAGEMENT",
    "operationId": "Operation1"
    }
]